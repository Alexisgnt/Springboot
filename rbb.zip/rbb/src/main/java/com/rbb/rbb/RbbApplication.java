package com.rbb.rbb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RbbApplication {

	public static void main(String[] args) {
		SpringApplication.run(RbbApplication.class, args);
	}

}
