package com.rbb.rbb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RbbApplicationTests {

	@Test
	void contextLoads() {
	}

}
